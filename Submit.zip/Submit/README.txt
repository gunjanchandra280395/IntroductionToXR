Introduction To XR

The build is available for Mac as I was facing errors while building for Windows PC.
